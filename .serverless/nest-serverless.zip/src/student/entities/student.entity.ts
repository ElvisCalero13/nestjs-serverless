export default interface Student {
  id: string;
  dni: string;
  name: string;
  lastname: string;
  career: string;
  level: number;
}
